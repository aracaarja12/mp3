Hudson set up where the anonymous user do not have any permissions whatsoever (including the read access.)

Any logged in user has full access to the system.